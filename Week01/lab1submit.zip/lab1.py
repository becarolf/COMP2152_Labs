# Sample Coding Question Week 01
# Beatriz Ferreira - 101176410


# Question 2: Defining an array (list)
my_array = [1, 4, 7, 9]


# Question 3: Order of Operations
a = 1
b = 2
c = 3
d = 4

# Fully bracketed version
e = (a - ((b ** c) // d)) + (a % c)
print("Question 3 result is: ", e)


# Question 4: Formatting
temperature = 32.6
print("The temperature today is: {:.3f} degrees Celsius".format(temperature))


# Question 5: Common Functions
userAge = int(input("Enter your age: "))
userAge = userAge + 22
print("Now showing the shop items filtred by age", userAge)